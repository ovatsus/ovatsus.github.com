﻿using System.Diagnostics;
using System.Linq.Expressions;
using ExpressionCodeDomVisualizer;
using Microsoft.VisualStudio.DebuggerVisualizers;

[assembly: DebuggerVisualizer(
    typeof(ExpressionCodeDomVisualizer.ExpressionCodeDomVisualizer), 
    typeof(ExpressionCodeDomVisualizerObjectSource), 
    Target = typeof(Expression), 
    Description = "Expression CodeDom Visualizer")]

namespace ExpressionCodeDomVisualizer {

    public class ExpressionCodeDomVisualizer : DialogDebuggerVisualizer {

        protected override void Show(IDialogVisualizerService windowService, IVisualizerObjectProvider objectProvider) {
            windowService.ShowDialog(new ExpressionCodeDomVisualizerForm((string)objectProvider.GetObject()));
        }
    }
}