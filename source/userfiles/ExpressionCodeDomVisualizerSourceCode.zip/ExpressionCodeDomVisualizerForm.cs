﻿using System.Drawing;
using System.Windows.Forms;

namespace ExpressionCodeDomVisualizer {

    public class ExpressionCodeDomVisualizerForm : Form {

        private TextBox codeTextBox;
        private string code;

        private void InitializeComponent() {
            this.codeTextBox = new TextBox();

            this.SuspendLayout();

            this.codeTextBox.Dock = DockStyle.Fill;
            this.codeTextBox.Multiline = true;
            this.codeTextBox.ReadOnly = true;
            this.codeTextBox.ScrollBars = ScrollBars.Both;
            this.codeTextBox.Text = this.code;

            this.Controls.AddRange(new Control[] { this.codeTextBox });
            this.Text = "Expression CodeDom Visualizer";

            this.ResumeLayout(false);

            this.Size = new Size(800, 600);
        }

        public ExpressionCodeDomVisualizerForm(string code) {
            this.code = code;
            InitializeComponent();
        }
    }
}