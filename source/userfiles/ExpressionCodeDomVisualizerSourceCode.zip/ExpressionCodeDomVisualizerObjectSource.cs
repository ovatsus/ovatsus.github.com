﻿using System.IO;
using System.Linq.Expressions;
using Microsoft.VisualStudio.DebuggerVisualizers;

namespace ExpressionCodeDomVisualizer {

    public class ExpressionCodeDomVisualizerObjectSource : VisualizerObjectSource {

        public override void GetData(object target, Stream outgoingData) {
            Expression expr = (Expression)target;
            VisualizerObjectSource.Serialize(outgoingData, new CodeDomExpressionVisitor(expr).GenerateSource());
        }
    }
}